# Informe divulgativo — Reto 01: GIRS Ecuador 2024

Edición del documento original `Informe_Reto01.docx` (Isabel Paguay, Mateo Vera y Martín Andrade), adaptado fielmente a las orientaciones visuales de `formatoInforme.pdf` y a la sección «Informe divulgativo» de `Reto01.pdf`.

## Compilación

**Overleaf:** Nuevo proyecto → Subir proyecto → seleccionar el ZIP. Archivo principal: `main.tex`. Compilador: **pdfLaTeX**. La bibliografía usa **biblatex + Biber** (Overleaf lo ejecuta al compilar). Pulse «Recompile»; si las referencias no aparecen, «Recompile from scratch». La primera compilación local utilizada fue: `pdflatex main.tex`, `biber main`, `pdflatex main.tex` dos veces.

No se entregan fuentes tipográficas: Montserrat está disponible mediante el paquete público de LaTeX `montserrat`.

## Qué incluye

- `InformeReto01_PUCE_Revisado.pdf`: informe divulgativo, 11 páginas A4.
- `main.tex`: documento completo y editable con tablas, citas, figuras e hipervínculos.
- `referencias.bib`: bibliografía en estilo APA 7.
- `logo_puce_formato.png`: recurso gráfico extraído del PDF de formato facilitado para este mismo trabajo.
- `figuras/`: gráficos basados en los resultados ya publicados del Hito 3; incluye corrección de tamaños de grupos y gráfico adicional de varianza de PCA.
- `CAMBIOS_Y_VALIDACION.md`: qué se corrigió y qué falta reconciliar con Colab final.

## Dependencia con el notebook final

El profesor confirmó al equipo que el cuaderno de Colab final debe partir del **CSV ya limpio**, y ejecutar desde allí el procesamiento, la comparación de métodos, PCA y la generación de las figuras. El CSV debe mantener `CantonId` como texto. **Esta versión del informe es editorialmente completa, pero sus resultados deben cotejarse con el notebook final antes de la entrega en el aula virtual.** Si cambian las matrices, las semillas, el agrupamiento o las figuras, actualizar PDF y código fuente.

Los resultados utilizados proceden de los Hitos 2 y 3 del repositorio: https://github.com/2007Mateo/Aprendizaje_Automatico_Reto01
