# Registro de cambios respecto a Informe_Reto01.docx

**Estado:** revisión editorial y metodológica terminada. Validación cruzada con el notebook final pendiente de su integración, por acuerdo de trabajo.

## Correcciones implementadas

1. Se aplicó el modelo de `formatoInforme.pdf`: encabezado con identidad PUCE, papel A4, Montserrat, título y autores en la primera página; sin portada independiente; secciones numeradas, paginación y leyendas automáticas.
2. Se conservaron los tres autores, el contexto, el objetivo, los procedimientos, las tablas, los resultados, los perfiles, las conclusiones y las fuentes del Word. Se revisó y aclaró el lenguaje para técnicos municipales, evitando confundir clusters con ranking.
3. Se sustituyó la gráfica original de tamaño de grupos (que enfrentaba G0 de K-Means contra G0 de Ward sin asegurar correspondencia) por barras **ordenadas por tamaño dentro de cada algoritmo**; no presupone correspondencia entre etiquetas.
4. Se incluyó la comparación completa de K-Means y Ward para `k=2..6`, los mínimos por grupo y ARI entre métodos, en lugar de mostrar solo tres resultados seleccionados.
5. Se preservaron el gráfico de silueta, perfiles, sensibilidad, PCA y contribuciones; se añadió una figura calculada desde el archivo de resultados de PCA con varianza individual y acumulada de las cinco componentes.
6. Se amplió la discusión de cinco perfiles, aclarando unidades de kg/mes y t/mes, interpretando correctamente indicadores binarios, ejemplos municipales y sus límites.
7. Se incluyó una tabla con acciones de posible mejora **condicionadas a evidencia adicional**, distinta para cada perfil.
8. Se actualizó la sección de reproducibilidad: el **notebook final debe iniciar con el CSV limpio**, según indicación comunicada del profesor. No afirma que ese notebook ya haya sido ejecutado ni que exista una validación final contra él.
9. Se habilitaron citas y referencias bibliográficas automáticas APA 7 desde `referencias.bib` y referencias cruzadas a figuras y tablas.
10. Se verificó compilación con `pdflatex`/`biber`, 11 páginas A4, enlaces activos y ausencia de cortes de tablas o figuras tras la inspección de todas las páginas.

## Cifras fijadas en la edición actual y que se deben contrastar con el Colab final

- 221 municipios en fuente GIRS 2024, 215 y 204 en matrices.
- 17 incidencias (5 CSB sin denominador, 1 DIF>1, 11 RI ceros ambiguos); 4 CSB>1 conservados.
- K-Means `k=5` silueta `0.593507`; Ward `k=5` `0.578667`.
- ARI entre métodos `0.879070`; entre escenarios `0.841207` (25 municipios distintos), semillas K-Means ARI medio `0.994993`.
- Tamaños K-Means `107,42,29,19,18`; tamaños Ward **ordenados por volumen** `100,39,33,26,17`.
- PC1 `46.6633 %`, PC2 `18.0605 %`, acumulado `64.7238 %`; cuatro PC suman `90.7582 %`.

## Verificación obligatoria antes de entrega definitiva

- [ ] Comprobar el CSV limpio definitivo con identificadores `CantonId` tipo texto y diccionario de las cinco características.
- [ ] Reejecutar en Colab todas las celdas desde cero, sin rutas locales y con dependencias documentadas.
- [ ] Verificar que el notebook genere tablas, perfiles y figuras que coincidan con este PDF.
- [ ] Confirmar cifras del informe, ejemplos municipales y política sobre 11 ceros ambiguos.
- [ ] Compilar de nuevo `main.tex` y comprobar las referencias si cambia cualquier resultado.
